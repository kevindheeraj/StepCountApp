package com.example.stepcounterapp;

public interface StepListener {
    public void step(long timeNs);
}
